-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
-------------------------------------------------------------------------------
entity operatif is
  generic(CYCLES_ATTENTE: natural := 2*50_000_000);
  port(hex5, hex4, hex3, hex2, hex1, hex0: out std_logic_vector(6 downto 0);
       fin_minuterie: out std_logic;
       etape: in std_logic_vector(1 downto 0);
       ouvre, alarme, clk, resetn: in std_logic);
end entity;
-------------------------------------------------------------------------------
architecture rtl of operatif is
  type alphabet_type is array(character) of
    std_logic_vector(6 downto 0);
  constant alphabet : alphabet_type := 
      ('A' | 'a' => not 7x"77", -- A
       'B' | 'b' => not 7x"7c", -- B
       'C' | 'c' => not 7x"39", -- C
       'D' | 'd' => not 7x"5E", -- D
       'E' | 'e' => not 7x"79", -- E
       'F' | 'f' => not 7x"71", -- F
       'G' | 'g' => not 7x"3D", -- G
       'H' | 'h' => not 7x"76", -- H
       'I' | 'i' => not 7x"30", -- I
       'J' | 'j' => not 7x"1E", -- J
       'K' | 'k' => not 7x"7A", -- K
       'L' | 'l' => not 7x"38", -- L
       'M' | 'm' => not 7x"2B", -- M
       'N' | 'n' => not 7x"54", -- N
       'O' | 'o' => not 7x"5C", -- O
       'P' | 'p' => not 7x"73", -- P
       'Q' | 'q' => not 7x"67", -- Q
       'R' | 'r' => not 7x"50", -- R
       'S' | 's' => not 7x"6D", -- S
       'T' | 't' => not 7x"78", -- T
       'U' | 'u' => not 7x"3E", -- U
       'V' | 'v' => not 7x"2A", -- V
       'W' | 'w' => not 7x"6A", -- W
       'X' | 'x' => not 7x"49", -- X
       'Y' | 'y' => not 7x"6E", -- Y
       'Z' | 'z' => not 7x"5B", -- Z
       '0' => "1000000",  -- 0 
       '1' => "1111001",  -- 1 
       '2' => "0100100",  -- 2
       '3' => "0110000",  -- 3 
       '4' => "0011001",  -- 4 
       '5' => "0010010",  -- 5 
       '6' => "0000010",  -- 6 
       '7' => "1111000",  -- 7
       '8' => "0000000",  -- 8
       '9' => "0010000",  -- 9
       others => (others => '1'));
begin
  process(clk,resetn)
    --constant CYCLES_ATTENTE: natural := 2*50_000_000;
    variable cpt : natural range 0 to CYCLES_ATTENTE - 1;
  begin
    if resetn = '0' then
      cpt := 0;
    elsif rising_edge(clk) then
      if (ouvre = '0') and (alarme = '0') then
        cpt := 0;
        fin_minuterie <= '0';
      elsif cpt + 1 = CYCLES_ATTENTE - 1 then
        fin_minuterie <= '1';
      else
        cpt := cpt + 1;
      end if;
    end if;
  end process;
  
  process(alarme, ouvre, etape)
  begin   
    if alarme = '1' then   
--      hex5 <= alphabet('e');
--      hex4 <= alphabet('r');
--      hex3 <= alphabet('r');
--      hex2 <= alphabet('o');
--      hex1 <= alphabet('r');
--      hex0 <= alphabet(' ');
      hex5 <= alphabet('a');
      hex4 <= alphabet('l');
      hex3 <= alphabet('a');
      hex2 <= alphabet('r');
      hex1 <= alphabet('m');
      hex0 <= alphabet(' ');
    elsif ouvre = '1' then
      hex5 <= alphabet('o');
      hex4 <= alphabet('p');
      hex3 <= alphabet('e');
      hex2 <= alphabet('n');
      hex1 <= alphabet(' ');
      hex0 <= alphabet(' ');
    else
      case etape is
        when "00"   => hex5 <= alphabet('E');
                       hex4 <= alphabet('n');
                       hex3 <= alphabet('t');
                       hex2 <= alphabet('e');
                       hex1 <= alphabet('r');
                       hex0 <= alphabet('1');

        when "01"   => hex5 <= alphabet('E');
                       hex4 <= alphabet('n');
                       hex3 <= alphabet('t');
                       hex2 <= alphabet('e');
                       hex1 <= alphabet('r');
                       hex0 <= alphabet('2');

        when "10"   => hex5 <= alphabet('E');
                       hex4 <= alphabet('n');
                       hex3 <= alphabet('t');
                       hex2 <= alphabet('e');
                       hex1 <= alphabet('r');
                       hex0 <= alphabet('3');          

        when others => hex5 <= alphabet('E');
                       hex4 <= alphabet('n');
                       hex3 <= alphabet('t');
                       hex2 <= alphabet('e');
                       hex1 <= alphabet('r');
                       hex0 <= alphabet('4');
      end case;
    end if;
 end process;
end architecture;
-------------------------------------------------------------------------------
